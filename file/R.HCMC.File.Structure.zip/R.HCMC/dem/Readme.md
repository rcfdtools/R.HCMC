# Digital elevation model - DEM

`\dem`: carpeta para el almacenamiento de los modelos digitales de elevación en formato GeoTIFF (.tif), TIN, LIDAR (.laz, .las) y demás correspondientes.
