# Base de datos espacial, Geodatabase - GDB

`\gdb`: carpeta para el almacenamiento de las bases de datos espaciales o Geodatabase. Almacenar en este contenedor, archivos tipo .mdb, GDB File, Spatialite, Oracle y demás asociados.

> No almacene archivos de formas shapefile, tablas externas(Excel, .txt, .csv, .dbf) y grillas ráster como archivo en la raíz de este directorio, utilice las carpetas correspondientes.
