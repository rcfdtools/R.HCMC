# Gráficos e ilustraciones generales

`\graph`: carpeta para el almacenamiento de gráficos, figuras, ilustraciones y capturas de pantallas utilizadas de forma general en este curso o en la entrega de proyecto.

> Tenga en cuenta que cada actividad, dispone de su propia carpeta `graph`, para el almacenamiento de sus gráficos asociados.