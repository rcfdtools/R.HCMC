# Directorio de salida de geoprocesos automatizados

`\output`: carpeta de salida de las operaciones espaciales realizada mediante scripts en Python u otros lenguajes. 

> Este directorio se purga antes de ejecutar cualquier script, por lo que se recomienda extraer, comprimir o guardar una copia de los resultados obtenidos en ejecuciones anteriores.