# Archivos de formas vectoriales shapefile

`\shp`: carpeta para el almacenamiento de los archivos de forma shapefile (.shp) producidos o generados.

> Recuerde que cada shapefile se compone de 4 archivos: .shp, .shx, .prj, .dbf.  
>
> Puede incluir los archivos de metadatos .xml.